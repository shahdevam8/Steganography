import tkinter as tk
from tkinter import filedialog, messagebox
import os

def encode_text_in_image(input_image, output_image, secret_text):
    with open(input_image, 'rb') as file:
        img_data = bytearray(file.read())

    offset = 54 if input_image.endswith('.bmp') else 0
    secret_text += chr(0)
    secret_bits = ''.join(f'{ord(char):08b}' for char in secret_text)

    if offset + len(secret_bits) > len(img_data):
        raise ValueError("Image is too small to hide the message.")

    for i, bit in enumerate(secret_bits):
        img_data[offset + i] = (img_data[offset + i] & 0b11111110) | int(bit)

    with open(output_image, 'wb') as out_file:
        out_file.write(img_data)

def browse_input_file():
    file_path = filedialog.askopenfilename(filetypes=[("BMP files", "*.bmp")])
    input_entry.delete(0, tk.END)
    input_entry.insert(0, file_path)

def browse_output_file():
    file_path = filedialog.asksaveasfilename(defaultextension=".bmp", filetypes=[("BMP files", "*.bmp")])
    output_entry.delete(0, tk.END)
    output_entry.insert(0, file_path)

def hide_message():
    input_file = input_entry.get()
    output_file = output_entry.get()
    message = message_entry.get("1.0", tk.END).strip()
    if not input_file.endswith(".bmp") or not output_file.endswith(".bmp"):
        messagebox.showerror("Error", "Only BMP format supported.")
        return
    try:
        encode_text_in_image(input_file, output_file, message)
        messagebox.showinfo("Success", f"Message hidden in {output_file}")
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("Steganography - Hide Text in BMP Image")

tk.Label(root, text="Input BMP Image:").grid(row=0, column=0, sticky="e")
input_entry = tk.Entry(root, width=50)
input_entry.grid(row=0, column=1)
tk.Button(root, text="Browse", command=browse_input_file).grid(row=0, column=2)

tk.Label(root, text="Output BMP Image:").grid(row=1, column=0, sticky="e")
output_entry = tk.Entry(root, width=50)
output_entry.grid(row=1, column=1)
tk.Button(root, text="Browse", command=browse_output_file).grid(row=1, column=2)

tk.Label(root, text="Secret Message:").grid(row=2, column=0, sticky="ne")
message_entry = tk.Text(root, width=38, height=4)
message_entry.grid(row=2, column=1, pady=5)

tk.Button(root, text="Hide Message", command=hide_message).grid(row=3, column=1, pady=10)

root.mainloop()