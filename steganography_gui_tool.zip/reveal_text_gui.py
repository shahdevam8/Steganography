import tkinter as tk
from tkinter import filedialog, messagebox

def decode_text_from_image(image_file):
    with open(image_file, 'rb') as file:
        img_data = bytearray(file.read())

    offset = 54 if image_file.endswith('.bmp') else 0
    bits = []
    for byte in img_data[offset:]:
        bits.append(str(byte & 1))

    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        char = chr(int(''.join(byte), 2))
        if char == chr(0):
            break
        chars.append(char)

    return ''.join(chars)

def browse_file():
    file_path = filedialog.askopenfilename(filetypes=[("BMP files", "*.bmp")])
    input_entry.delete(0, tk.END)
    input_entry.insert(0, file_path)

def reveal_message():
    input_file = input_entry.get()
    if not input_file.endswith(".bmp"):
        messagebox.showerror("Error", "Only BMP format supported.")
        return
    try:
        message = decode_text_from_image(input_file)
        result_box.delete("1.0", tk.END)
        result_box.insert(tk.END, message)
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("Steganography - Reveal Hidden Text")

tk.Label(root, text="BMP Image with Hidden Message:").grid(row=0, column=0, sticky="e")
input_entry = tk.Entry(root, width=50)
input_entry.grid(row=0, column=1)
tk.Button(root, text="Browse", command=browse_file).grid(row=0, column=2)

tk.Button(root, text="Reveal Message", command=reveal_message).grid(row=1, column=1, pady=10)

tk.Label(root, text="Hidden Message:").grid(row=2, column=0, sticky="ne")
result_box = tk.Text(root, width=38, height=4)
result_box.grid(row=2, column=1, pady=5)

root.mainloop()